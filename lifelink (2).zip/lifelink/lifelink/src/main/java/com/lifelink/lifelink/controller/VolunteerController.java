package com.lifelink.lifelink.controller;

import com.lifelink.lifelink.entity.Volunteer;
import com.lifelink.lifelink.repository.VolunteerRepository;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class VolunteerController {

    private final VolunteerRepository volunteerRepository;

    public VolunteerController(VolunteerRepository volunteerRepository) {
        this.volunteerRepository = volunteerRepository;
    }

    // Volunteer registration page
    @GetMapping("/volunteer/register")
    public String volunteerRegister() {
        return "volunteer-register";
    }

    // Register a new volunteer
    @PostMapping("/volunteer/register")
    public String registerVolunteer(
            @RequestParam String name,
            @RequestParam String location,
            @RequestParam String contact,
            @RequestParam String availability) {

        Volunteer volunteer = new Volunteer();

        volunteer.setName(name);
        volunteer.setLocation(location);
        volunteer.setContact(contact);
        volunteer.setAvailability(availability);

        volunteerRepository.save(volunteer);

        return "redirect:/volunteer/list";
    }

    // Display all volunteers
    @GetMapping("/volunteer/list")
    public String volunteerList(Model model) {

        List<Volunteer> volunteers = volunteerRepository.findAll();

        model.addAttribute("volunteers", volunteers);

        return "volunteer-list";
    }

    // Search volunteers
    @GetMapping("/volunteer/search")
    public String searchVolunteers(
            @RequestParam(required = false) String location,
            @RequestParam(required = false) String availability,
            Model model) {

        List<Volunteer> volunteers;

        boolean hasLocation =
                location != null && !location.trim().isEmpty();

        boolean hasAvailability =
                availability != null && !availability.trim().isEmpty();

        if (hasLocation && hasAvailability) {

            volunteers =
                    volunteerRepository.findByLocationAndAvailability(
                            location.trim(),
                            availability.trim()
                    );

        } else if (hasLocation) {

            volunteers =
                    volunteerRepository.findByLocation(
                            location.trim()
                    );

        } else if (hasAvailability) {

            volunteers =
                    volunteerRepository.findByAvailability(
                            availability.trim()
                    );

        } else {

            volunteers = volunteerRepository.findAll();
        }

        model.addAttribute("volunteers", volunteers);
        model.addAttribute("searchLocation", location);
        model.addAttribute("searchAvailability", availability);

        return "volunteer-list";
    }
}