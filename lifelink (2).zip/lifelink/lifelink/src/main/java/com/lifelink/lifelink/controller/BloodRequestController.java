package com.lifelink.lifelink.controller;

import com.lifelink.lifelink.entity.BloodRequest;
import com.lifelink.lifelink.repository.BloodRequestRepository;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class BloodRequestController {

    private final BloodRequestRepository bloodRequestRepository;

    public BloodRequestController(BloodRequestRepository bloodRequestRepository) {
        this.bloodRequestRepository = bloodRequestRepository;
    }

    // Show blood request page
    @GetMapping("/request")
    public String requestPage(Model model) {

        List<BloodRequest> requests = bloodRequestRepository.findAll();

        model.addAttribute("requests", requests);

        return "blood-request";
    }

    // Submit blood request
    @PostMapping("/request")
    public String createRequest(
            @RequestParam String patientName,
            @RequestParam String bloodGroup,
            @RequestParam String location,
            @RequestParam String contact,
            @RequestParam String urgency) {

        BloodRequest request = new BloodRequest();

        request.setPatientName(patientName);
        request.setBloodGroup(bloodGroup);
        request.setLocation(location);
        request.setContact(contact);
        request.setUrgency(urgency);

        bloodRequestRepository.save(request);

        return "redirect:/request";
    }
}