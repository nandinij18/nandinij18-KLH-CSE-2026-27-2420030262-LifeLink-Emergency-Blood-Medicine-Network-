package com.lifelink.lifelink.repository;

import com.lifelink.lifelink.entity.Medicine;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MedicineRepository extends JpaRepository<Medicine, Long> {

    List<Medicine> findByNameContainingIgnoreCase(String name);

    List<Medicine> findByLocationIgnoreCase(String location);

    List<Medicine> findByAvailabilityIgnoreCase(String availability);

    List<Medicine> findByNameContainingIgnoreCaseAndLocationIgnoreCase(
            String name,
            String location
    );
}