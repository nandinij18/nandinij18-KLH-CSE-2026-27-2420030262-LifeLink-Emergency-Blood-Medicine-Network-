package com.lifelink.lifelink.repository;

import com.lifelink.lifelink.entity.Donor;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DonorRepository extends JpaRepository<Donor, Long> {

    List<Donor> findByBloodGroup(String bloodGroup);

    List<Donor> findByLocation(String location);

    List<Donor> findByBloodGroupAndLocation(String bloodGroup, String location);
}