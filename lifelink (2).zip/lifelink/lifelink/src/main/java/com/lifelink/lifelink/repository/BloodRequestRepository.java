package com.lifelink.lifelink.repository;

import com.lifelink.lifelink.entity.BloodRequest;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BloodRequestRepository extends JpaRepository<BloodRequest, Long> {

    List<BloodRequest> findByBloodGroup(String bloodGroup);

    List<BloodRequest> findByLocationContainingIgnoreCase(String location);
}