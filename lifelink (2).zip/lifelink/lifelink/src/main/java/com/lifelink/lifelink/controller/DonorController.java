package com.lifelink.lifelink.controller;

import com.lifelink.lifelink.entity.Donor;
import com.lifelink.lifelink.repository.DonorRepository;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class DonorController {

    private final DonorRepository donorRepository;

    public DonorController(DonorRepository donorRepository) {
        this.donorRepository = donorRepository;
    }

    // Show donor registration page
    @GetMapping("/donor/register")
    public String donorRegister() {
        return "donor-register";
    }

    // Save donor details
    @PostMapping("/donor/register")
    public String registerDonor(
            @RequestParam String name,
            @RequestParam String bloodGroup,
            @RequestParam String location,
            @RequestParam String contact,
            @RequestParam boolean available) {

        Donor donor = new Donor();

        donor.setName(name);
        donor.setBloodGroup(bloodGroup);
        donor.setLocation(location);
        donor.setContact(contact);
        donor.setAvailable(available);

        donorRepository.save(donor);

        return "redirect:/donor/register";
    }
}