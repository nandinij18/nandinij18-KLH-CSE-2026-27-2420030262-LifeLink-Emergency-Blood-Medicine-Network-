package com.lifelink.lifelink.controller;

import com.lifelink.lifelink.entity.Medicine;
import com.lifelink.lifelink.repository.MedicineRepository;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class MedicineController {

    private final MedicineRepository medicineRepository;

    public MedicineController(MedicineRepository medicineRepository) {
        this.medicineRepository = medicineRepository;
    }

    // Show medicine search page
    @GetMapping("/medicine")
    public String medicinePage(Model model) {

        List<Medicine> medicines = medicineRepository.findAll();

        model.addAttribute("medicines", medicines);
        model.addAttribute("searchName", "");
        model.addAttribute("searchLocation", "");

        return "medicine";
    }

    // Search medicines
    @GetMapping("/medicine/search")
    public String searchMedicines(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String location,
            Model model) {

        List<Medicine> medicines;

        boolean hasName = name != null && !name.trim().isEmpty();
        boolean hasLocation = location != null && !location.trim().isEmpty();

        if (hasName && hasLocation) {

            medicines =
                    medicineRepository
                            .findByNameContainingIgnoreCaseAndLocationIgnoreCase(
                                    name.trim(),
                                    location.trim()
                            );

        } else if (hasName) {

            medicines =
                    medicineRepository
                            .findByNameContainingIgnoreCase(name.trim());

        } else if (hasLocation) {

            medicines =
                    medicineRepository
                            .findByLocationIgnoreCase(location.trim());

        } else {

            medicines = medicineRepository.findAll();
        }

        model.addAttribute("medicines", medicines);
        model.addAttribute("searchName", name);
        model.addAttribute("searchLocation", location);

        return "medicine";
    }

    // Add medicine
    @PostMapping("/medicine/add")
    public String addMedicine(
            @RequestParam String name,
            @RequestParam String category,
            @RequestParam String pharmacyName,
            @RequestParam String location,
            @RequestParam String contact,
            @RequestParam String availability) {

        Medicine medicine = new Medicine();

        medicine.setName(name);
        medicine.setCategory(category);
        medicine.setPharmacyName(pharmacyName);
        medicine.setLocation(location);
        medicine.setContact(contact);
        medicine.setAvailability(availability);

        medicineRepository.save(medicine);

        return "redirect:/medicine";
    }
}