package com.lifelink.lifelink.controller;

import com.lifelink.lifelink.entity.Donor;
import com.lifelink.lifelink.repository.DonorRepository;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class DonorSearchController {

    private final DonorRepository donorRepository;

    public DonorSearchController(DonorRepository donorRepository) {
        this.donorRepository = donorRepository;
    }

    @GetMapping("/donor/search")
    public String searchDonors(
            @RequestParam(required = false) String bloodGroup,
            @RequestParam(required = false) String location,
            Model model) {

        List<Donor> donors;

        if (bloodGroup != null && location != null
                && !bloodGroup.isEmpty() && !location.isEmpty()) {

            donors = donorRepository.findByBloodGroupAndLocation(
                    bloodGroup, location);

        } else if (bloodGroup != null && !bloodGroup.isEmpty()) {

            donors = donorRepository.findByBloodGroup(bloodGroup);

        } else if (location != null && !location.isEmpty()) {

            donors = donorRepository.findByLocation(location);

        } else {

            donors = donorRepository.findAll();
        }

        model.addAttribute("donors", donors);

        // Keep the selected search values
        model.addAttribute("selectedBloodGroup", bloodGroup);
        model.addAttribute("selectedLocation", location);

        return "donor-search";
    }
}