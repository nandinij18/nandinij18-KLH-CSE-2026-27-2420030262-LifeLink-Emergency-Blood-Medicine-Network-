package com.lifelink.lifelink.controller;

import com.lifelink.lifelink.entity.User;
import com.lifelink.lifelink.repository.UserRepository;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

    private final UserRepository userRepository;

    private final BCryptPasswordEncoder passwordEncoder =
            new BCryptPasswordEncoder();

    public HomeController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // Main page
    @GetMapping("/")
    public String home() {
        return "redirect:/login";
    }

    // Dashboard
    @GetMapping("/home")
    public String dashboard() {
        return "home";
    }

    // Login page
    @GetMapping("/login")
    public String login() {
        return "login";
    }

    // Login processing
    @PostMapping("/login")
    public String loginUser(
            @RequestParam String phone,
            @RequestParam String password) {

        User user = userRepository.findByPhone(phone);

        if (user != null &&
                passwordEncoder.matches(password, user.getPassword())) {

            return "redirect:/home";
        }

        return "redirect:/login?error=true";
    }

    // Registration page
    @GetMapping("/register")
    public String register() {
        return "register";
    }

    // Registration processing
    @PostMapping("/register")
    public String registerUser(
            @RequestParam String name,
            @RequestParam String phone,
            @RequestParam String password,
            @RequestParam String confirmPassword,
            Model model) {

        // Check whether phone number already exists
        if (userRepository.existsByPhone(phone)) {
            return "redirect:/register?error=exists";
        }

        // Check whether passwords match
        if (!password.equals(confirmPassword)) {
            return "redirect:/register?error=password";
        }

        // Create new user
        User user = new User();

        user.setName(name);
        user.setPhone(phone);

        // Store encrypted password
        user.setPassword(
                passwordEncoder.encode(password)
        );

        userRepository.save(user);

        return "redirect:/login?registered=true";
    }
}