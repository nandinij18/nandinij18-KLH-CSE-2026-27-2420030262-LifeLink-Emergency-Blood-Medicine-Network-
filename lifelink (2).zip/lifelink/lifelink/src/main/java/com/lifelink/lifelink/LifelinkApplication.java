package com.lifelink.lifelink;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableJpaRepositories(basePackages = "com.lifelink.lifelink.repository")
public class LifelinkApplication {

    public static void main(String[] args) {
        SpringApplication.run(LifelinkApplication.class, args);
    }
}