package com.lifelink.lifelink.repository;

import com.lifelink.lifelink.entity.Volunteer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VolunteerRepository extends JpaRepository<Volunteer, Long> {

    List<Volunteer> findByLocation(String location);

    List<Volunteer> findByAvailability(String availability);

    List<Volunteer> findByLocationAndAvailability(
            String location, String availability);
}